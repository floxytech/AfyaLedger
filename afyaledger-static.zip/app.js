document.addEventListener("DOMContentLoaded", () => {
  console.log("AfyaLedger static site loaded.");
});